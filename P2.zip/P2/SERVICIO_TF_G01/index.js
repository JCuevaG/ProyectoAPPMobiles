const express = require('express')
const mysql = require('mysql2')
const bodyParser = require('body-parser')

const app = express()
app.use(bodyParser.json())

const PUERTO = 2040

const conexion = mysql.createConnection(
    {
        host:'localhost',
        database:'servicio_tf_g01',
        user:'root',
        password:'123456'
    }
)

conexion.connect(error =>{
    if(error) throw error
    console.log('Conexion a la bd fue exitosa')
})

app.listen(PUERTO, () => {
    console.log('Servidor corriendo en el puerto ' + PUERTO)
})

app.get('/', (req,res)=>{
    res.end('Bienvenido al servicio web del grupo 01 (trabajo final)')
})

app.get('/tipoUsuario', (req, res)=>{
    const consulta = "SELECT * FROM tipoUsuario"
    conexion.query(consulta,(error,resultado)=>{
        if(error) return console.error(error.message)

            const obj = {}
            if(resultado.length > 0){
                obj.listaTipoUsuarios = resultado
                res.json(obj)                
            }else{
                res.json('No hay registros')
            }
    })
})

app.get('/usuario', (req, res)=>{
    const consulta = "SELECT * FROM usuario"
    conexion.query(consulta,(error,resultado)=>{
        if(error) return console.error(error.message)

            const obj = {}
            if(resultado.length > 0){
                obj.listaUsuarios = resultado
                res.json(obj)                
            }else{
                res.json('No hay registros')
            }
    })
})

app.post('/usuario/agregar', (req, res) => {
    const usuario = {
        usu_correo: req.body.usu_correo,
        usu_pass: req.body.usu_pass,
        usu_nombres: req.body.usu_nombres,
        usu_DNI: req.body.usu_DNI,
        usu_fecNac: req.body.usu_fecNac,
        usu_celular: req.body.usu_celular,
        tipoUsu_id: req.body.tipoUsu_id
    }

    const query = "INSERT INTO usuario SET ?"
    conexion.query(query, usuario, (error) =>{
        if(error) return console.error(error.message)
        res.json("Se insertó correctamente el usuario")
    })
})

app.get('/usuario/:id', (req, res) =>{
    const {id} = req.params

    const query = "SELECT * FROM persona WHERE per_id=" + id
    conexion.query(query, [id], (error, respuesta) =>{
        if(error) return console.error(error.message)

        if(respuesta.length > 0){
            res.json(respuesta[0])
        }else{
            res.json("no hay registros")
        }
    })
})


app.get('/parametros', (req, res) => {
    const tamanio = req.query.tamanio || '';
    const tipoProducto = req.query.tipoProducto || 0;
    const peso = req.query.peso || 0;
    const cantidad = req.query.cantidad || 0;
    const cargadores = req.query.cargadores || 0;
  
    const query = `SELECT * FROM parametros_calculo WHERE '${tamanio}' between TamanioDesde and TamanioHasta
    and '${peso}' between PesoDesde and PesoHasta
    and '${cantidad}' between CantidadDesde and CantidadHasta
    and  Cargadores= '${cargadores}'
    `;
  
    conexion.query(query, (err, resultado) => {
      if(err) return console.error(err.message)
    const obj = {} 
    
      if(resultado.length > 0){
        obj.listaparametros = resultado;
        res.json(obj);
      }
      else{
        res.json("No hay registros")
      }
  
      // res.json(resultado);
    });
  });