package com.trabajofinal.grupo01
import com.google.gson.GsonBuilder
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

object AppConstantes{
    const val BASE_URL="http://192.168.18.8:2040"
}

interface WebService {
    @GET("/parametros")
    suspend fun obtenerParametros(@Query("tamanio") tamanio: Int, @Query("tipoProducto") tipoProducto:Int,@Query("peso") peso:Double, @Query("cantidad") cantidad: Int, @Query("cargadores") cargadores: Int):Response<ParametroResponse>
}


object RetrofitClient{
    val webServices: WebService by lazy {
        Retrofit.Builder()
            .baseUrl(AppConstantes.BASE_URL)
            .addConverterFactory(GsonConverterFactory.create(GsonBuilder().create()))
            .build().create(WebService::class.java)
    }
}