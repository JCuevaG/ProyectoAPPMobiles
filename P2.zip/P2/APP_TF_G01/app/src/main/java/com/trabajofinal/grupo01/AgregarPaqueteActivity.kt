package com.trabajofinal.grupo01

import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.Dispatcher

class AgregarPaqueteActivity : AppCompatActivity() {

    private lateinit var txt_Tamanio:EditText
    private lateinit var txt_Peso:EditText
    private lateinit var txt_Cantidad:EditText
    private lateinit var txt_Cargadores:EditText
    private lateinit var txt_Observaciones:EditText
    private lateinit var btn_Continuar:Button
    private lateinit var btn_Cancelar:Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_agregar_paquete)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.mainAgregarPaquete)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        asignarReferencias()
    }

    private fun asignarReferencias() {
        txt_Tamanio = findViewById(R.id.txt_tamanio)
        txt_Peso = findViewById(R.id.txt_peso)
        txt_Cantidad = findViewById(R.id.txt_cantidad)
        txt_Cargadores = findViewById(R.id.txt_cargadores)
        txt_Observaciones = findViewById(R.id.txt_observaciones)
        btn_Continuar = findViewById(R.id.btnContinuar)
        btn_Cancelar = findViewById(R.id.btnCancelar)

        btn_Continuar.setOnClickListener{
            buscarParametro()
        }

        btn_Cancelar.setOnClickListener{
            val intent = Intent(this, OriginLocationActivity::class.java)
            startActivity(intent)
        }
    }

    private fun buscarParametro() {
        val txtTamanio = txt_Tamanio.text.toString().toInt()
        val txtPeso = txt_Peso.text.toString().toDouble()
        val txtCantidad = txt_Cantidad.text.toString().toInt()
        val txtCargadores = txt_Cargadores.text.toString().toInt()
        val tipoProducto = 0

        CoroutineScope(Dispatchers.IO).launch {
            val rpta = RetrofitClient.webServices.obtenerParametros(txtTamanio,tipoProducto,txtPeso,txtCantidad,txtCargadores)
            runOnUiThread{
                if (rpta.isSuccessful) {
                    val parametro = rpta.body()

                    if (parametro != null){
                        mostrarMensaje("El precio del servicio es: S/" + parametro.listaparametros[0].Monto.toString())
                    }

                }
            }
        }

    }


    private fun mostrarMensaje(mensaje:String){
        val ventana = AlertDialog.Builder(this)
        ventana.setTitle("Informacion")
        ventana.setMessage(mensaje)
        ventana.setPositiveButton("Aceptar", DialogInterface.OnClickListener{ dialog, which ->
            val intent = Intent(this,ResumenActivity::class.java)
            startActivity(intent)
        })
        ventana.setNegativeButton("Cancelar") { dialog, _ ->
            dialog.cancel()
        }
        ventana.create().show()
    }

}