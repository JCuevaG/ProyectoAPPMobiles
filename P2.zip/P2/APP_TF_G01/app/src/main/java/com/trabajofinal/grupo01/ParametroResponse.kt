package com.trabajofinal.grupo01

import com.google.gson.annotations.SerializedName

data class ParametroResponse(
    @SerializedName("listaparametros") var listaparametros: ArrayList<Parametro>
)
