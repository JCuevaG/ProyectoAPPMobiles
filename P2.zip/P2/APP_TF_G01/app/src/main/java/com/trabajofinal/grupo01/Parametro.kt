package com.trabajofinal.grupo01

data class Parametro(
    var nombre: String,
    var idPARAMETROS_CALCULO: Double,
    var TamanioDesde: Double,
    var TamanioHasta: Double,
    var IdTipoProducto: Int,
    var PesoDesde: Double,
    var PesoHasta: Double,
    var CantidadDesde: Int,
    var CantidadHasta: Int,
    var Cargadores: Int,
    var Monto: Double,
    var Origen: Double,
    var Destino: Double,
    var KilometrajeDesde: Int,
    var KilometrajeHasta: Int

)
