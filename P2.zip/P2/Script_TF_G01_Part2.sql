use servicio_tf_g01;


CREATE TABLE `parametros_calculo` (
  `idPARAMETROS_CALCULO` int NOT NULL,
  `TamanioDesde` decimal(18,2) DEFAULT NULL,
  `TamanioHasta` decimal(18,2) DEFAULT NULL,
  `IdTipoProducto` int DEFAULT NULL,
  `PesoDesde` decimal(18,2) DEFAULT NULL,
  `PesoHasta` decimal(18,2) DEFAULT NULL,
  `CantidadDesde` int DEFAULT NULL,
  `CantidadHasta` int DEFAULT NULL,
  `Cargadores` int DEFAULT NULL,
  `Monto` decimal(18,2) DEFAULT NULL,
  `Origen` decimal(20,18) DEFAULT NULL,
  `Destino` decimal(20,18) DEFAULT NULL,
  `KilometrajeDesde` int DEFAULT NULL,
  `KilometrajeHasta` int DEFAULT NULL,
  PRIMARY KEY (`idPARAMETROS_CALCULO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


INSERT INTO `servicio_tf_g01`.`parametros_calculo`
(`idPARAMETROS_CALCULO`,`TamanioDesde`,`TamanioHasta`,`IdTipoProducto`,`PesoDesde`,`PesoHasta`,`CantidadDesde`,`CantidadHasta`,
`Cargadores`,`Monto`,`Origen`,`Destino`,`KilometrajeDesde`,`KilometrajeHasta`)
VALUES
(1,1,2,1,0.10,10,1,5,1,50,null,null,1,10);

INSERT INTO `servicio_tf_g01`.`parametros_calculo`
(`idPARAMETROS_CALCULO`,`TamanioDesde`,`TamanioHasta`,`IdTipoProducto`,`PesoDesde`,`PesoHasta`,`CantidadDesde`,`CantidadHasta`,
`Cargadores`,`Monto`,`Origen`,`Destino`,`KilometrajeDesde`,`KilometrajeHasta`)
VALUES
(2,1,2,1,0.10,10,1,5,2,80,null,null,1,10);

INSERT INTO `servicio_tf_g01`.`parametros_calculo`
(`idPARAMETROS_CALCULO`,`TamanioDesde`,`TamanioHasta`,`IdTipoProducto`,`PesoDesde`,`PesoHasta`,`CantidadDesde`,`CantidadHasta`,
`Cargadores`,`Monto`,`Origen`,`Destino`,`KilometrajeDesde`,`KilometrajeHasta`)
VALUES
(3,1,2,1,0.10,10,1,5,3,110,null,null,1,10);

INSERT INTO `servicio_tf_g01`.`parametros_calculo`
(`idPARAMETROS_CALCULO`,`TamanioDesde`,`TamanioHasta`,`IdTipoProducto`,`PesoDesde`,`PesoHasta`,`CantidadDesde`,`CantidadHasta`,
`Cargadores`,`Monto`,`Origen`,`Destino`,`KilometrajeDesde`,`KilometrajeHasta`)
VALUES
(4,1,2,1,0.10,10,1,5,4,140,null,null,1,10);

INSERT INTO `servicio_tf_g01`.`parametros_calculo`
(`idPARAMETROS_CALCULO`,`TamanioDesde`,`TamanioHasta`,`IdTipoProducto`,`PesoDesde`,`PesoHasta`,`CantidadDesde`,`CantidadHasta`,
`Cargadores`,`Monto`,`Origen`,`Destino`,`KilometrajeDesde`,`KilometrajeHasta`)
VALUES
(5,3,10,1,1,40,1,5,0,200,null,null,1,10);
INSERT INTO `servicio_tf_g01`.`parametros_calculo`
(`idPARAMETROS_CALCULO`,`TamanioDesde`,`TamanioHasta`,`IdTipoProducto`,`PesoDesde`,`PesoHasta`,`CantidadDesde`,`CantidadHasta`,
`Cargadores`,`Monto`,`Origen`,`Destino`,`KilometrajeDesde`,`KilometrajeHasta`)
VALUES
(6,3,10,1,1,40,1,5,1,250,null,null,1,10);
INSERT INTO `servicio_tf_g01`.`parametros_calculo`
(`idPARAMETROS_CALCULO`,`TamanioDesde`,`TamanioHasta`,`IdTipoProducto`,`PesoDesde`,`PesoHasta`,`CantidadDesde`,`CantidadHasta`,
`Cargadores`,`Monto`,`Origen`,`Destino`,`KilometrajeDesde`,`KilometrajeHasta`)
VALUES
(7,3,10,1,1,40,1,5,2,300,null,null,1,10);

INSERT INTO `servicio_tf_g01`.`parametros_calculo`
(`idPARAMETROS_CALCULO`,`TamanioDesde`,`TamanioHasta`,`IdTipoProducto`,`PesoDesde`,`PesoHasta`,`CantidadDesde`,`CantidadHasta`,
`Cargadores`,`Monto`,`Origen`,`Destino`,`KilometrajeDesde`,`KilometrajeHasta`)
VALUES
(8,3,10,1,1,40,1,5,3,350,null,null,1,10);
