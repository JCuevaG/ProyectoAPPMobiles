create database servicio_tf_g1;

use servicio_tf_g1;

create table tipoUsuario
(
tipoUsu_id int not null auto_increment,
tipoUsu_descripcion varchar(45),
primary key(tipoUsu_id)
);

insert into tipoUsuario values (null, 'Cliente Regular');
insert into tipoUsuario values (null, 'Cliente Mayorista');
insert into tipoUsuario values (null, 'Transportista');

select*from tipoUsuario;

create table usuario
(
usu_id int not null auto_increment,
usu_correo varchar(100),
usu_pass varchar(100),
usu_nombres varchar(100),
usu_DNI varchar(8),
usu_fecNac datetime,
usu_celular varchar(9),
tipoUsu_id int,
primary key(usu_id),
key tipoUsu_id_x (tipoUsu_id),
constraint tipoUsu_id foreign key (tipoUsu_id) references tipoUsuario (tipoUsu_id)
);

insert into usuario values (null, 'U20191A242@upc.edu.pe', '123', 'Luis Valentín', '12345678', '1991-06-24', '994768403', 3);

select*from usuario;